# Class Object

Constructors
------------------------------------------------

1. `(parent)`

### Arguments
- `1.`:
    * `parent`: parent object. Must be an `Object` or its derivate.
    
### Description
- `1.`:  
    Creates an `Object` having `parent` as parent.
