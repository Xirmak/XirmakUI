# pfUI-CustomMedia

A status bar texture package for [pfUI](https://github.com/shagu/pfUI), providing additional textures for the unit frames.

## Preview

![pfUI-CustomMedia](https://i.imgur.com/Og1aHck.jpg)

## Installation (Vanilla, 1.12)
1. Download **[Latest Version](https://github.com/mrrosh/pfUI-CustomMedia/archive/master.zip)**
2. Unpack the Zip file
3. Rename the folder "pfUI-CustomMedia-master" to "pfUI-CustomMedia"
4. Copy "pfUI-CustomMedia" into Wow-Directory\Interface\AddOns
5. Restart Wow

## Installation (The Burning Crusade, 2.4.3)
1. Download **[Latest Version](https://github.com/mrrosh/pfUI-CustomMedia/archive/master.zip)**
2. Unpack the Zip file
3. Rename the folder "pfUI-CustomMedia-master" to "pfUI-CustomMedia-tbc"
4. Copy "pfUI-CustomMedia-tbc" into Wow-Directory\Interface\AddOns
5. Restart Wow
