# pfUI-fonts

A font package for pfUI, providing additional fonts from the google font project.

## Installation (Vanilla, 1.12)
1. Download **[Latest Version](https://github.com/mrrosh/pfUI-MoreFonts/archive/refs/heads/master.zip)**
2. Unpack the Zip file
3. Rename the folder "pfUI-MoreFonts-master" to "pfUI-MoreFonts"
4. Copy "pfUI-MoreFonts" into Wow-Directory\Interface\AddOns
5. Restart Wow

## Installation (The Burning Crusade, 2.4.3)
1. Download **[Latest Version](https://github.com/mrrosh/pfUI-MoreFonts/archive/refs/heads/master.zip)**
2. Unpack the Zip file
3. Rename the folder "pfUI-MoreFonts-master" to "pfUI-MoreFonts-tbc"
4. Copy "pfUI-MoreFonts-tbc" into Wow-Directory\Interface\AddOns
5. Restart Wow

## Preview
![thumbnails](https://i.imgur.com/WvSA0r6.png)
