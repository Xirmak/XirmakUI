# pfUI Weak Icons

An extension for pfUI which allows the creation of aura icons, much like MPOWA.

![screenshot](https://i.imgur.com/2uo6Rs7.jpeg)

## Installation (Vanilla, 1.12)
1. Download **[Latest Version](https://github.com/mrrosh/pfUI-WeakIcons/archive/master.zip)**
2. Unpack the Zip file
3. Rename the folder "pfUI-WeakIcons-master" to "pfUI-WeakIcons"
4. Copy "pfUI-WeakIcons" into Wow-Directory\Interface\AddOns
5. Restart Wow


## Credits
Original author [vetu104](https://github.com/vetu104/pfUI-auraicons/)
