# pfUI Elite Overlay

An extension for pfUI which adds dragon textures to elite, rare and worldbosses.

![screenshot](https://raw.githubusercontent.com/shagu/ShaguAddons/master/_img/pfUI-eliteoverlay/screenshot.png)

## Installation (Vanilla, 1.12)
1. Download **[Latest Version](https://github.com/shagu/pfUI-eliteoverlay/archive/master.zip)**
2. Unpack the Zip file
3. Rename the folder "pfUI-eliteoverlay-master" to "pfUI-eliteoverlay"
4. Copy "pfUI-eliteoverlay" into Wow-Directory\Interface\AddOns
5. Restart Wow

## Installation (The Burning Crusade, 2.4.3)
1. Download **[Latest Version](https://github.com/shagu/pfUI-eliteoverlay/archive/master.zip)**
2. Unpack the Zip file
3. Rename the folder "pfUI-eliteoverlay-master" to "pfUI-eliteoverlay-tbc"
4. Copy "pfUI-eliteoverlay-tbc" into Wow-Directory\Interface\AddOns
5. Restart Wow

## Credits
Artwork by [GaMu-ChAn](https://www.deviantart.com/gamu-chan/art/WOW-Elite-frame-143568653)
