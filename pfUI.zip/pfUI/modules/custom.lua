pfUI:RegisterModule("custom", function ()
  pfUI.customicons = pfUI.customicons or {}

  -- Override icon: replace DeadofNight texture with correct Repent icon
  pfUI.uf = pfUI.uf or {}
  pfUI.uf.debufficons = pfUI.uf.debufficons or {}
  pfUI.uf.debufficons["Interface\\Icons\\Spell_Shadow_DeadofNight"] = "Interface\\Icons\\Spell_Holy_PrayerofHealing"
end)
